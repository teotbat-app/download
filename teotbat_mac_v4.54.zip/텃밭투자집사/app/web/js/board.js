/* ==========================================================================
   board.js — 🌱 임시 텃밭 게시판 (텃밭투자집사 전용, v4.42)
   · 로그인 없이 익명: 폰마다 '당근 농부 #7' 같은 별명이 저절로 정해짐(쿠폰 서버가 기기 코드로 정함)
   · 글·공감·신고(2번이면 저절로 가려짐)·내 글 지우기 (v4.43: 댓글 없음 — 글만)
   · 연락처·링크·종목 추천·리딩 관련 글은 금지 — 앱과 서버 두 곳에서 막음
   · 글은 운영자 구글 시트 [게시판] 탭에 저장. 더보기 메뉴에서 열어요.
   ========================================================================== */
'use strict';

const BOARD_CATS = [['all', '전체'], ['공지', '📢 공지'], ['자유', '💬 자유'], ['질문', '❓ 질문'], ['건의', '💡 앱 건의']];
const BOARD_WRITE_CATS = [['자유', '💬 자유'], ['질문', '❓ 질문'], ['건의', '💡 앱 건의']];
const BOARD_BAN = [
  /카톡|카카오\s*톡|오픈\s*채팅|오픈\s*톡|open\.kakao|텔레\s*그램|텔레방|telegram|t\.me\/|밴드\s*주소|band\.us|디스코드|discord|라인\s*아이디/i,
  /https?:\/\/|www\.|[a-z0-9-]+\.(com|kr|net|io|me|ly|gg|co)\b/i,
  /01[016789][\s.\-]?\d{3,4}[\s.\-]?\d{4}/,
  /리딩|무료\s*추천|종목\s*추천|추천\s*종목|수익\s*보장|원금\s*보장|무조건\s*(오|올|상승|수익)|급등\s*(주|예정|임박)|작전\s*주|따라\s*사|vip\s*방|유료\s*방|입장\s*문의|문의\s*주세요|수익\s*인증/i,
];
let BOARD = null, _bdCat = 'all', _bdBusy = false, _bdErr = '';

if (typeof ED !== 'undefined' && ED === 'tb' && typeof MORE_PAGES !== 'undefined' && !MORE_PAGES.some(x => x[0] === 'board'))
  MORE_PAGES.unshift(['board', '임시 텃밭 게시판', 'message', '🌱 텃밭 사용자끼리 익명으로 이야기']);

function bdAgo(t) {
  if (!t) return '';
  const s = (Date.now() - t) / 1000;
  if (s < 60) return '방금'; if (s < 3600) return Math.floor(s / 60) + '분 전'; if (s < 86400) return Math.floor(s / 3600) + '시간 전';
  if (s < 86400 * 7) return Math.floor(s / 86400) + '일 전';
  const d = new Date(t); return (d.getMonth() + 1) + '/' + d.getDate();
}
function bdBad(t) { return BOARD_BAN.some(r => r.test(t)); }
// v4.46: 별명은 내가 정해요 (2~8글자, 뒤에 폰마다 #번호가 붙음)
const BD_RESERVED = /운영|관리|공지|admin|manager|staff|official|공식|개발자|텃밭\s*투자|투자\s*집사|집사님|매니저|스태프|고객\s*센터|상담/i;
function bdMyNick() { return String((UI && UI.bdNick) || ''); }
function bdNickErr(t) {
  if (!t) return '';
  if (t.length < 2 || t.length > 8) return '별명은 2~8글자로 정해 주세요';
  if (!/^[가-힣a-zA-Z0-9 _]+$/.test(t)) return '별명은 한글·영어·숫자만 쓸 수 있어요';
  if (BD_RESERVED.test(t) || bdBad(t)) return '그 별명은 쓸 수 없어요 (운영자·관리자처럼 헷갈리는 말은 안 돼요)';
  return '';
}
const bdText = t => esc(t).replace(/\n/g, '<br>');

async function boardLoad() {
  _bdBusy = true; _bdErr = '';
  let d = null;
  try { d = await api('/api/board?nick=' + encodeURIComponent(bdMyNick()), { timeout: 25000 }); } catch (e) {}
  _bdBusy = false;
  if (d && d.ok) BOARD = d; else _bdErr = (d && d.error) || SERVER_DOWN;
  if (route.page === 'board') PAGES.board({}, true);
  const open = document.getElementById('bdPost'); if (open && open._id) boardRefreshPost(open._id);
}

PAGES.board = function (params, isRe) {
  const el = pageEl('board'); if (!el) return;
  if (ED !== 'tb') { el.innerHTML = '<div class="page-head"><div><h1>임시 텃밭 게시판</h1></div></div><div class="card"><p class="note" style="margin:0">텃밭투자집사 앱에서만 쓸 수 있어요.</p></div>'; return; }
  const posts = BOARD ? BOARD.posts.filter(p => _bdCat === 'all' || p.cat === _bdCat) : [];
  const list = !BOARD ? (_bdErr ? '<div class="card"><p class="note" style="margin:0">😥 ' + esc(_bdErr) + '</p><button class="btn btn-soft btn-sm" data-act="bd-reload" style="margin-top:10px">다시 불러오기</button></div>'
      : '<div class="card"><div class="skel" style="height:70px;margin-bottom:10px"></div><div class="skel" style="height:70px"></div></div>')
    : posts.length ? posts.map(p => bdCardHtml(p)).join('')
    : '<div class="card"><div class="empty" style="padding:18px 6px"><div class="ill">' + icon('message') + '</div><b>아직 글이 없어요</b><p>첫 글을 남겨 보세요. 앱 쓰다가 궁금한 점, 건의, 가벼운 이야기 모두 좋아요.</p></div></div>';
  el.innerHTML =
    '<div class="page-head"><div><h1>🌱 임시 텃밭 게시판</h1><div class="desc">텃밭 사용자끼리 익명으로 나누는 이야기' + (BOARD && BOARD.me && BOARD.me.nick ? ' · 나는 <b>' + esc((BOARD.me.emoji || '') + ' ' + BOARD.me.nick) + '</b>' : '') + '</div></div>' +
      '<div class="actions"><button class="btn btn-outline" data-act="bd-reload">' + icon('refresh', 'ic-sm') + '새로고침</button></div></div>' +
    '<div class="bd-rule">🚨 <b>운영자는 1:1로 연락하지 않아요.</b> 따로 연락하자거나 종목을 찍어 주는 사람은 <b>사기</b>예요.<br>📌 <b>규칙</b> — 종목 추천·리딩방 홍보·연락처(카톡·전화)·링크는 금지예요. 이 게시판 글은 투자 권유가 아니고, 투자 판단은 각자 하세요. <b>신고 2번이면 저절로 가려져요.</b></div>' +
    '<div class="bd-cats">' + BOARD_CATS.map(([k, l]) => '<button data-act="bd-cat" data-v="' + k + '" class="' + (_bdCat === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' +
    '<div class="bd-list">' + list + '</div>' +
    '<button class="bd-fab" data-act="bd-write">✏️ 글쓰기</button>';
  hydrateIcons(el);
  if (!isRe || (!BOARD && !_bdBusy && !_bdErr)) boardLoad();
};

function bdCardHtml(p) {
  return '<div class="bd-post' + (p.op ? ' op' : '') + '" data-act="bd-open" data-id="' + esc(p.id) + '">' +
    '<div class="bd-ph"><span class="bd-av">' + esc(p.emoji || '🌱') + '</span><span class="bd-nick">' + esc(p.nick) + (p.mine ? ' <i class="bd-me">나</i>' : '') + '</span><span class="bd-at">· ' + esc(bdAgo(p.at)) + '</span>' +
      '<span class="bd-tag">' + esc((BOARD_CATS.find(c => c[0] === p.cat) || [0, p.cat])[1]) + '</span></div>' +
    '<div class="bd-pt">' + esc(p.title) + '</div><div class="bd-pb">' + bdText(p.body) + '</div>' +
    '<div class="bd-pf"><button class="bd-like' + (p.liked ? ' on' : '') + '" data-act="bd-like" data-id="' + esc(p.id) + '">' + (p.liked ? '❤️' : '🤍') + ' <b>' + p.likes + '</b></button>' +
      '</div></div>';
}

/* 글 자세히 (댓글 없음) */
function openBoardPost(id) {
  const p = BOARD && BOARD.posts.find(x => x.id === id); if (!p) return;
  const m = openModal({ title: '🌱 임시 텃밭 게시판', size: 'wide', body: '<div id="bdPostIn"></div>' });
  m.el.id = 'bdPost'; m.el._id = id;
  boardRefreshPost(id);
  m.body.addEventListener('click', async e => {
    const b = e.target.closest('[data-bd]'); if (!b) return;
    const k = b.dataset.bd, tid = b.dataset.id;
    if (k === 'report') bdReport(tid);
    else if (k === 'del') bdDelete(tid, tid === id ? m : null);
  });
}
function boardRefreshPost(id) {
  const box = document.getElementById('bdPostIn'); if (!box) return;
  const p = BOARD && BOARD.posts.find(x => x.id === id);
  if (!p) { box.innerHTML = '<p class="note">글이 없어졌거나 가려졌어요.</p>'; return; }
  const tools = x => (x.mine ? '<button class="bd-mini" data-bd="del" data-id="' + esc(x.id) + '">🗑 지우기</button>'
    : x.op ? '' : '<button class="bd-mini' + (x.reported ? ' done' : '') + '" data-bd="report" data-id="' + esc(x.id) + '"' + (x.reported ? ' disabled' : '') + '>' + (x.reported ? '신고함' : '🚩 신고') + '</button>');
  box.innerHTML =
    '<div class="bd-ph"><span class="bd-av">' + esc(p.emoji || '🌱') + '</span><span class="bd-nick">' + esc(p.nick) + (p.mine ? ' <i class="bd-me">나</i>' : '') + '</span><span class="bd-at">· ' + esc(bdAgo(p.at)) + '</span>' +
      '<span class="bd-tag">' + esc((BOARD_CATS.find(c => c[0] === p.cat) || [0, p.cat])[1]) + '</span></div>' +
    '<h3 class="bd-dt">' + esc(p.title) + '</h3><div class="bd-db">' + bdText(p.body) + '</div>' +
    '<div class="bd-pf"><button class="bd-like' + (p.liked ? ' on' : '') + '" data-act="bd-like" data-id="' + esc(p.id) + '">' + (p.liked ? '❤️' : '🤍') + ' 공감 <b>' + p.likes + '</b></button>' + tools(p) + '</div>' +
    '<p class="note" style="margin:8px 0 0">연락처·링크·종목 추천은 금지라 올라가지 않아요. 계좌·비밀번호는 절대 적지 마세요.</p>';
}

/* 글쓰기 */
function openBoardWrite() {
  if (ED !== 'tb') return;
  let cat = '자유';
  const me = BOARD && BOARD.me && BOARD.me.nick ? BOARD.me : null;
  const m = openModal({ title: '✏️ 익명으로 글쓰기', sticky: true, body:
    '<div class="bd-lbl">내 별명 <small>2~8글자 · 비우면 ' + esc(me && !bdMyNick() ? me.nick : '자동 별명') + '</small></div>' +
    '<input class="input" id="bdK" maxlength="8" placeholder="예: 새싹투자자" value="' + esc(bdMyNick()) + '">' +
    '<p class="bd-warn" style="margin-top:4px">별명 뒤에 이 폰만의 번호(#7 같은)가 붙어서, 누가 같은 별명을 써도 구별돼요.</p>' +
    '<div class="bd-lbl">말머리</div><div class="bd-cats" id="bdWc">' + BOARD_WRITE_CATS.map(([k, l]) => '<button data-c="' + k + '" class="' + (k === cat ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' +
    '<div class="bd-lbl">제목</div><input class="input" id="bdT" maxlength="60" placeholder="한 줄로 적어 주세요">' +
    '<div class="bd-lbl">내용 <small id="bdN">0 / 500</small></div><textarea class="input" id="bdB" maxlength="500" rows="6" placeholder="궁금한 점이나 나누고 싶은 이야기"></textarea>' +
    '<p class="bd-warn">⚠️ 금지: 종목 추천·리딩방 홍보·카톡 아이디·전화번호·링크 (올라가지 않아요). 계좌·비밀번호는 절대 적지 마세요. 글·별명은 운영자 시트에 저장되고, 문제 글은 가려질 수 있어요.</p>' +
    '<div class="lic-msg" id="bdMsg"></div>',
    foot: '<button class="btn btn-primary btn-block btn-lg" id="bdGo">올리기</button>' });
  const K = m.body.querySelector('#bdK'), T = m.body.querySelector('#bdT'), B = m.body.querySelector('#bdB'), N = m.body.querySelector('#bdN'), msg = m.body.querySelector('#bdMsg');
  B.oninput = () => { N.textContent = B.value.length + ' / 500'; };
  m.body.querySelector('#bdWc').onclick = e => { const b = e.target.closest('[data-c]'); if (!b) return; cat = b.dataset.c; m.body.querySelectorAll('#bdWc button').forEach(x => x.classList.toggle('on', x === b)); };
  m.foot.querySelector('#bdGo').onclick = async () => {
    const title = T.value.trim(), body = B.value.trim(), nick = K.value.replace(/\s+/g, ' ').trim();
    const bad = t => { msg.className = 'lic-msg bad'; msg.textContent = t; };
    const ne = bdNickErr(nick); if (ne) { bad(ne); K.focus(); return; }
    if (title.length < 2) { bad('제목을 2글자 이상 적어 주세요'); T.focus(); return; }
    if (!body) { bad('내용을 적어 주세요'); B.focus(); return; }
    if (bdBad(title + '\n' + body)) { bad('연락처·링크·종목 추천·리딩 관련 글은 금지라 올릴 수 없어요'); return; }
    const go = m.foot.querySelector('#bdGo'); go.disabled = true; msg.className = 'lic-msg'; msg.textContent = '올리는 중…';
    const r = await bdSend('post', { cat, title, body, nick }, t => bad(t));
    go.disabled = false;
    if (r) { if (UI.bdNick !== nick) { UI.bdNick = nick; saveUI(); } m.close(); toast('🌱 글을 올렸어요', 2200); _bdCat = 'all'; boardLoad(); }
  };
  setTimeout(() => (bdMyNick() ? T : K).focus(), 250);
}

async function bdSend(act, body, onErr) {
  let r = null;
  try { r = await api('/api/board/' + act, { method: 'POST', body, timeout: 25000 }); } catch (e) {}
  if (!r || !r.ok) { const t = (r && r.error) || SERVER_DOWN; if (onErr) onErr(t); else toast(t, 3500); return null; }
  return r;
}
async function bdLike(id) {
  const p = BOARD && BOARD.posts.find(x => x.id === id); if (!p) return;
  p.liked = !p.liked; p.likes += p.liked ? 1 : -1;                // 먼저 화면에 반영(빠르게)
  if (route.page === 'board') PAGES.board({}, true); boardRefreshPost(id);
  const r = await bdSend('like', { id });
  if (r) { p.likes = r.likes; p.liked = r.liked; } else { p.liked = !p.liked; p.likes += p.liked ? 1 : -1; }
  if (route.page === 'board') PAGES.board({}, true); boardRefreshPost(id);
}
async function bdReport(id) {
  if (!(await confirmBox({ title: '🚩 신고하기', msg: '이 글을 신고할까요?<br>신고가 <b>2번</b> 모이면 저절로 가려지고, 운영자가 확인해요.', ok: '신고', danger: true }))) return;
  const r = await bdSend('report', { id });
  if (r) { toast(r.hidden ? '🚩 신고했어요 · 가려졌어요' : '🚩 신고했어요', 2500); boardLoad(); }
}
async function bdDelete(id, modal) {
  if (!(await confirmBox({ title: '🗑 지우기', msg: '내가 쓴 이 글을 지울까요?', ok: '지우기', danger: true }))) return;
  const r = await bdSend('delete', { id });
  if (r) { toast('지웠어요', 1800); if (modal) modal.close(); boardLoad(); }
}

Object.assign(ACT, {
  'bd-reload': () => { BOARD = BOARD || null; boardLoad(); },
  'bd-cat': el => { _bdCat = el.dataset.v; PAGES.board({}, true); },
  'bd-open': el => openBoardPost(el.dataset.id),
  'bd-like': el => bdLike(el.dataset.id),
  'bd-write': () => openBoardWrite(),
});
