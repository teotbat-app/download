/* ==========================================================================
   paper.js — 🎮 포인트 모의투자 (v2.21)
   퀴즈·출석으로 모은 포인트(1P = 1원)로 관심종목을 연습으로 사고팔아 보기.
   v4.49: 원칙을 녹인 사기·팔기 화면(paperTradeRules) — 내 규칙(rules.js)과 견줘 보여 줌. 원격 스위치 'rules'.
   실제 돈·실제 주문과는 아무 관계 없음. 포인트는 현금으로 바꿀 수 없음.
   ========================================================================== */
'use strict';

const PAPER_FEE = 0.00015;                                 // 수수료 흉내 (0.015%)
function PP() {
  const s = S.settings;
  if (!s.paper || typeof s.paper !== 'object') s.paper = { pos: [], hist: [], realized: 0 };
  return s.paper;
}
function paperRate(ccy) { return ccy === 'USD' ? fx() : 1; }
function paperCur(t) {                                      // 현재가: 모의 보유에 받아 둔 시세 → 관심·보유 시세
  const T = String(t || '').toUpperCase(), q = PP().pos.find(x => x.t === T);
  const w = watchlist().find(x => String(x.ticker || '').toUpperCase() === T), h = allHoldings().find(x => String(x.h.ticker || '').toUpperCase() === T);
  const cands = [q && q.cur > 0 ? [q.cur, q.cat || 0] : null, w && w.cur > 0 ? [num(w.cur), w.at || 0] : null, h && h.h.cur > 0 ? [num(h.h.cur), 1] : null].filter(Boolean);
  cands.sort((x, y) => y[1] - x[1]);                       // 가장 최근에 받은 값
  return cands.length ? cands[0][0] : 0;
}
function paperValue() {                                     // 지금 시세 기준 모의 계좌
  let v = 0, cost = 0, day = 0, stale = 0;
  PP().pos.forEach(p => {
    const c = paperCur(p.t), r = paperRate(p.ccy);
    if (!c) stale++;
    const px = c || p.avg; v += px * p.qty * r; cost += p.avg * p.qty * r;
    if (c && p.chg != null && isFinite(p.chg) && p.cat && Date.now() - p.cat < 86400000) day += px * p.qty * r * (p.chg / (100 + p.chg));
  });
  return { v, cost, pl: v - cost, day, stale };
}
/* 모의 보유 종목 시세 받기 (관심종목에서 지워도 따로 받음) */
let _ppBusy = false, _ppAt = 0;
async function refreshPaperPrices(force) {
  const pos = PP().pos; if (!pos.length || _ppBusy) return false;
  if (!force && Date.now() - _ppAt < 60000) return false;
  _ppBusy = true;
  try {
    const items = [...new Set(pos.map(p => p.t + ':' + (p.mkt || 'kr')))].join(',');
    const data = await api('/prices?items=' + encodeURIComponent(items), { timeout: 60000 });
    let ok = 0;
    pos.forEach(p => {
      const d = data && data[p.t + ':' + (p.mkt || 'kr')];
      if (d && d.price > 0) { p.cur = d.price; p.cat = Date.now(); ok++; if (d.change_pct != null && isFinite(d.change_pct)) p.chg = d.change_pct; }
    });
    if (ok) { _ppAt = Date.now(); save({ noSync: true }); }
    return ok > 0;
  } catch (e) { return false; } finally { _ppBusy = false; }
}
function paperRefreshNow(btn) {
  if (btn) btn.classList.add('spin');
  refreshPaperPrices(true).then(ok => { if (!ok) toast('시세를 받지 못했어요 — 잠시 후 다시 눌러 주세요'); paperRerender(); });
}
setInterval(() => {                                         // 관심 탭을 보고 있는 동안 1분마다 자동 갱신
  if (route && route.page === 'watch' && !document.hidden && feat('paper') && PP().pos.length)
    refreshPaperPrices(false).then(ok => { if (ok) paperRerender(); });
}, 60000);
async function openPaperTrade(it) {
  const x = { t: String(it.ticker || '').toUpperCase(), n: it.name || it.ticker, mkt: it.market || (/^[A-Za-z]/.test(it.ticker || '') ? 'us' : 'kr') };
  x.ccy = it.ccy || (x.mkt === 'us' ? 'USD' : 'KRW');
  let cur = num(it.cur) || paperCur(x.t), chg = it.chg != null && isFinite(it.chg) ? +it.chg : null;
  const sellMode = it.mode === 'sell';                       // v4.41: 보유 종목의 [팔기]로 열었을 때
  const m = openModal({ title: '🎮 모의투자 · ' + esc(x.n), body: '<div class="ai-loading" style="padding:20px"><div class="orb"></div><div>현재가 확인 중…</div></div>' });
  try { const d = await api('/price?ticker=' + encodeURIComponent(x.t) + '&market=' + x.mkt, { timeout: 20000 }); if (d && d.price > 0) { cur = d.price; if (d.change_pct != null && isFinite(d.change_pct)) chg = +d.change_pct; } } catch (e) {}
  if (m.closed) return;
  { const q0 = PP().pos.find(p => p.t === x.t); if (q0 && cur > 0) { q0.cur = cur; q0.cat = Date.now(); } }
  if (!(cur > 0)) { m.setBody('<p class="note">현재가를 받지 못해 모의투자를 할 수 없어요. 잠시 후 다시 해 주세요.</p>'); return; }
  const rate = paperRate(x.ccy);
  if (rulesOn()) { paperTradeRules(m, x, cur, rate, chg, sellMode ? 'sell' : 'buy'); return; }   // v4.49: 원칙을 녹인 사기·팔기 화면
  const draw = () => {
    const g = G(), pos = PP().pos.find(p => p.t === x.t), maxQ = Math.floor(g.pts / (cur * rate * (1 + PAPER_FEE)));
    const pl = pos ? (cur - pos.avg) * pos.qty * rate : 0;
    m.setBody('<div class="pp-head"><div><span>현재가</span><b>' + esc(priceTxt(cur, x.ccy)) + '</b>' + (rate > 1 ? '<em>1주 = ' + nf(Math.round(cur * rate), 0) + 'P</em>' : '') + '</div>' +
        '<div><span>내 포인트</span><b>💎 ' + nf(g.pts, 0) + 'P</b></div></div>' +
      (pos ? '<div class="pp-pos"><b>보유 ' + nf(pos.qty, 0) + '주 · 평균 ' + esc(priceTxt(pos.avg, x.ccy)) + '</b><span class="' + cls(pl) + '">' + (pl >= 0 ? '+' : '') + nf(Math.round(pl), 0) + 'P (' + pct((cur / pos.avg - 1) * 100) + ')</span></div>' : '') +
      '<div class="field" style="margin-top:12px"><label>수량 (주)</label><input class="input tnum lg" id="ppQ" inputmode="numeric" value="' + (sellMode && pos ? pos.qty : pos ? '' : Math.min(1, maxQ) || '') + '" placeholder="몇 주?"></div>' +
      '<div class="chips" id="ppQuick">' + [['10%', .1], ['25%', .25], ['50%', .5], ['최대', 1]].map(([l, r]) => '<button class="chip" data-r="' + r + '">살 수 있는 ' + l + '</button>').join('') +
        (pos ? '<button class="chip" data-all>보유 전부</button>' : '') + '</div>' +
      '<div class="pp-sum" id="ppSum"></div>' +
      '<div class="row-btns" style="margin-top:12px"><button class="btn ' + (sellMode && pos ? 'btn-outline' : 'btn-primary') + ' btn-lg" style="flex:1" id="ppBuy">사기</button><button class="btn ' + (sellMode && pos ? 'btn-primary' : 'btn-outline') + ' btn-lg" style="flex:1" id="ppSell"' + (pos ? '' : ' disabled') + '>팔기</button></div>' +
      '<p class="note" style="margin-top:10px">게임·출석 포인트로 하는 <b>연습용 모의투자</b>예요 (1P = 1원). 실제 주문이 아니고, 포인트는 현금으로 바꿀 수 없어요. 시세는 15~20분 늦을 수 있어요.</p>');
    const q = m.body.querySelector('#ppQ'), sum = m.body.querySelector('#ppSum');
    const upd = () => { const n = Math.floor(num(q.value)); sum.textContent = n > 0 ? n + '주 ≈ ' + nf(Math.round(n * cur * rate), 0) + 'P (수수료 ' + nf(Math.ceil(n * cur * rate * PAPER_FEE), 0) + 'P)' : '살 수 있는 수량: 최대 ' + nf(maxQ, 0) + '주'; };
    q.oninput = upd; upd();
    m.body.querySelector('#ppQuick').onclick = e => { const b = e.target.closest('[data-r],[data-all]'); if (!b) return; q.value = b.dataset.all != null ? pos.qty : Math.max(0, Math.floor(maxQ * +b.dataset.r)); upd(); };
    m.body.querySelector('#ppBuy').onclick = () => {
      const n = Math.floor(num(q.value)), cost = Math.ceil(n * cur * rate * (1 + PAPER_FEE));
      if (!(n > 0)) { toast('수량을 넣어 주세요'); return; }
      if (cost > G().pts) { toast('포인트가 모자라요 — 출석하거나 투자 퀴즈를 풀어 포인트를 받아 보세요'); return; }
      G().pts -= cost;
      const P = PP(); let p = P.pos.find(y => y.t === x.t);
      if (p) { p.avg = (p.avg * p.qty + cur * n) / (p.qty + n); p.qty += n; } else P.pos.push(p = { t: x.t, n: x.n, mkt: x.mkt, ccy: x.ccy, qty: n, avg: cur, at: Date.now() });
      p.cur = cur; p.cat = Date.now();
      P.hist.unshift({ k: 'buy', t: x.t, n: x.n, q: n, p: cur, ccy: x.ccy, at: Date.now() }); P.hist = P.hist.slice(0, 100);
      if (!inWatch(x.t, x.ccy)) watchlist().push({ ticker: x.t, name: x.n, market: x.mkt, ccy: x.ccy, cur, at: Date.now() });
      save(); toast('🎮 ' + x.n + ' ' + n + '주 모의 매수 (-' + nf(cost, 0) + 'P)'); draw(); paperRerender();
    };
    m.body.querySelector('#ppSell').onclick = () => {
      const P = PP(), p = P.pos.find(y => y.t === x.t); if (!p) return;
      const n = Math.min(p.qty, Math.floor(num(q.value)) || 0); if (!(n > 0)) { toast('팔 수량을 넣어 주세요'); return; }
      const get = Math.floor(n * cur * rate * (1 - PAPER_FEE)), gain = Math.round((cur - p.avg) * n * rate);
      G().pts += get; P.realized += gain; p.qty -= n; if (p.qty <= 0) P.pos = P.pos.filter(y => y !== p);
      P.hist.unshift({ k: 'sell', t: x.t, n: x.n, q: n, p: cur, ccy: x.ccy, gain, at: Date.now() }); P.hist = P.hist.slice(0, 100);
      save(); toast((gain >= 0 ? '🎉 ' : '') + x.n + ' ' + n + '주 모의 매도 (' + (gain >= 0 ? '+' : '') + nf(gain, 0) + 'P)'); draw(); paperRerender();
    };
  };
  draw();
}
/* v4.49: 원칙을 녹인 사기·팔기 화면 (원격 스위치 'rules' 가 켜졌을 때)
   · 살 때: 내 규칙대로 나눠 사기(몇 번째인지) · 왜 사는지 한 줄 · 다시 볼 날 · 사면 한 종목이 몇 %가 되는지 · 급하게 오른 날 알림
   · 팔 때: 살 때 적은 이유 다시 보기 · 이유가 바뀌었는지 · 나눠 팔기
   앱은 사라/팔아라 하지 않고, 본인이 정한 규칙과 견줘 보여 주기만 함. 넘어도 막지 않음. */
function ppJosa(w) {                                        // 한빛전자'가' · 삼성'이' — 받침에 맞춘 조사 (한글이 아니면 '이(가)')
  const c = String(w || '').trim().slice(-1).charCodeAt(0);
  return c >= 0xAC00 && c <= 0xD7A3 ? ((c - 0xAC00) % 28 ? '이' : '가') : '이(가)';
}
function paperTradeRules(m, x, cur, rate, chg, mode) {
  const ui = { why: '', rev: 0, hot: false, same: '', q: null, part: '' };
  const fee = n => Math.ceil(n * cur * rate * PAPER_FEE);
  const draw = () => {
    const g = G(), P = PP(), pos = P.pos.find(p => p.t === x.t), r = RU();
    if (mode === 'sell' && !pos) mode = 'buy';
    const V = paperValue(), eq = g.pts + V.v, unit = cur * rate * (1 + PAPER_FEE);
    const maxQ = Math.floor(g.pts / unit), posVal = pos ? cur * pos.qty * rate : 0, pl = pos ? (cur - pos.avg) * pos.qty * rate : 0;
    const buys = pos ? (pos.buys || 1) : 0, k = buys + 1;                       // 이번이 몇 번째 사기인지
    const part = eq * r.max / 100 / r.split;                                    // 한 번에 살 분량 = (한 종목 한도) ÷ (나눠 사는 횟수)
    const partQ = Math.max(0, Math.min(maxQ, Math.floor(part / unit)));
    const head = '<div class="pp-head"><div><span>현재가' + (chg != null ? ' <em class="' + cls(chg) + '">오늘 ' + pct(chg) + '</em>' : '') + '</span><b>' + esc(priceTxt(cur, x.ccy)) + '</b>' + (rate > 1 ? '<em>1주 = ' + nf(Math.round(cur * rate), 0) + 'P</em>' : '') + '</div>' +
        '<div><span>내 포인트</span><b>💎 ' + nf(g.pts, 0) + 'P</b></div></div>' +
      (pos ? '<div class="pp-pos"><b>보유 ' + nf(pos.qty, 0) + '주 · 평균 ' + esc(priceTxt(pos.avg, x.ccy)) + '</b><span class="' + cls(pl) + '">' + (pl >= 0 ? '+' : '') + nf(Math.round(pl), 0) + 'P (' + pct((cur / pos.avg - 1) * 100) + ')</span></div>' : '');
    const foot = '<p class="note" style="margin-top:10px">포인트로 하는 <b>연습용 모의투자</b>예요 (1P = 1원). 실제 주문이 아니고, 포인트는 현금으로 바꿀 수 없어요. 시세는 15~20분 늦을 수 있어요.</p>';
    if (mode === 'buy') {
      if (ui.q == null) ui.q = k <= r.split ? (partQ || '') : '';
      if (!ui.rev) ui.rev = r.review;
      const hot = chg != null && chg >= 8 && !ui.hot;
      m.setBody(head +
        (rulesSet() ? '' : '<div class="pp-tip"><span>🧭 한 종목 비중과 나눠 사는 횟수를 <b>내 규칙</b>으로 정해 두면 여기서 견줘 보여 드려요.</span><button class="btn btn-soft btn-sm" id="ppSetRules">정하기</button></div>') +
        (hot ? '<div class="pp-warn">📈 <b>오늘 ' + Math.round(chg) + '% 오른 종목이에요.</b> 급하게 오를 때 따라 사면 후회하기 쉬워요.<div class="pp-warn-b"><button class="on" id="ppLater">관심에 두고 내일 다시 보기</button><button id="ppHotOk">그래도 살게요</button></div></div>' : '') +
        '<div class="pp-lb"><span>나눠 사기 <small>· 내 규칙: ' + r.split + '번에 나눠서</small></span><small>' + (k <= r.split ? k + '번째' : r.split + '번을 다 샀어요') + '</small></div>' +
        '<div class="pp-plan">' + Array.from({ length: r.split }, (_, i) => '<span class="' + (i + 1 < k ? 'done' : i + 1 === k ? 'on' : '') + '">' + (i + 1 < k ? '✓ ' : '') + (i + 1) + '번째' + (i + 1 === k ? ' · 1/' + r.split : '') + '</span>').join('') + '</div>' +
        (k > r.split ? '<p class="pp-mini warn">정해 둔 ' + r.split + '번을 이미 다 샀어요. 더 사면 내 규칙보다 많이 사게 돼요.</p>' : '') +
        '<div class="field" style="margin-top:12px"><label>수량 (주)</label><input class="input tnum lg" id="ppQ" inputmode="numeric" value="' + esc(String(ui.q)) + '" placeholder="몇 주?"></div>' +
        '<div class="chips" id="ppQuick">' + (partQ > 0 ? '<button class="chip" data-q="' + partQ + '">이번 분량 ' + nf(partQ, 0) + '주</button>' : '') + (maxQ >= 1 && partQ !== 1 ? '<button class="chip" data-q="1">1주만</button>' : '') + '</div>' +
        (pos && pos.why ? '<div class="pp-why"><small>살 때 내가 적은 이유</small>“' + esc(pos.why) + '”</div>'
          : '<div class="pp-lb"><span>왜 사나요? <small>· 한 줄이면 돼요</small></span></div><input class="input" id="ppWhy" maxlength="60" value="' + esc(ui.why) + '" placeholder="예: 주문이 두 분기 잇따라 늘어서">') +
        (!pos || !pos.review ? '<div class="pp-lb"><span>언제 다시 볼까요?</span></div><div class="chips" id="ppRev">' + RU_OPT.review.map(o => '<button class="chip' + (ui.rev === o[0] ? ' pick' : '') + '" data-d="' + o[0] + '">' + o[1] + ' 뒤</button>').join('') + '</div>' : '') +
        '<div class="pp-wt" id="ppSum"></div>' +
        '<div class="row-btns pp-btns" style="margin-top:12px"><button class="btn btn-primary btn-lg" style="flex:2" id="ppBuy">사기</button>' + (pos ? '<button class="btn btn-outline btn-lg" style="flex:1" id="ppToSell">팔기</button>' : '') + '</div>' + foot);
      const q = m.body.querySelector('#ppQ'), sum = m.body.querySelector('#ppSum'), buyB = m.body.querySelector('#ppBuy'), why = m.body.querySelector('#ppWhy');
      const upd = () => {
        const n = Math.floor(num(q.value)); ui.q = q.value;
        buyB.textContent = n > 0 ? nf(n, 0) + '주 사기' + (k <= r.split ? ' (' + k + '번째)' : '') : '사기';
        if (!(n > 0)) { sum.className = 'pp-wt'; sum.innerHTML = '살 수 있는 수량: 최대 ' + nf(maxQ, 0) + '주'; return; }
        const amt = n * cur * rate, w = eq > 0 ? (posVal + amt) / eq * 100 : 0, cash = eq > 0 ? (g.pts - amt - fee(n)) / eq * 100 : 0;
        const over = w > r.max + .5, low = cash < r.cash - .5;
        sum.className = 'pp-wt' + (over || low ? ' bad' : '');
        sum.innerHTML = nf(n, 0) + '주 ≈ ' + nf(Math.round(amt), 0) + 'P <small>(수수료 ' + nf(fee(n), 0) + 'P)</small><br>' +
          '이만큼 사면 <b>' + esc(x.n) + '</b>' + ppJosa(x.n) + ' 내 모의계좌의 <b>' + Math.round(w) + '%</b>가 돼요.' + (over ? ' 내 규칙은 <b>한 종목 ' + r.max + '%까지</b>예요.' : '') +
          '<div class="pp-bar"><i style="width:' + Math.max(2, Math.min(100, w / Math.max(r.max * 1.6, 1) * 100)) + '%"></i><u style="left:' + (100 / 1.6) + '%"></u></div>' +
          (low ? '사고 나면 현금이 <b>' + Math.max(0, Math.round(cash)) + '%</b> 남아요. 내 규칙은 <b>현금 ' + r.cash + '% 이상</b>이에요.' : '');
      };
      q.oninput = upd; upd();
      if (why) why.oninput = () => { ui.why = why.value; };
      m.body.onclick = e => {
        const c = e.target.closest('#ppQuick [data-q]'); if (c) { q.value = c.dataset.q; upd(); return; }
        const d = e.target.closest('#ppRev [data-d]'); if (d) { ui.rev = +d.dataset.d; m.body.querySelectorAll('#ppRev .chip').forEach(b => b.classList.toggle('pick', b === d)); return; }
        if (e.target.closest('#ppSetRules')) { openMyRules(() => { ui.q = null; ui.rev = 0; draw(); paperRerender(); }); return; }
        if (e.target.closest('#ppHotOk')) { ui.hot = true; draw(); return; }
        if (e.target.closest('#ppLater')) {
          if (!inWatch(x.t, x.ccy)) { watchlist().push({ ticker: x.t, name: x.n, market: x.mkt, ccy: x.ccy, cur, at: Date.now() }); save(); }
          m.close(); toast('⭐ 관심종목에 담아 뒀어요. 내일 다시 봐요', 2600); paperRerender(); return;
        }
        if (e.target.closest('#ppToSell')) { mode = 'sell'; ui.q = null; draw(); return; }
        if (e.target.closest('#ppBuy')) {
          const n = Math.floor(num(q.value)), cost = Math.ceil(n * cur * rate * (1 + PAPER_FEE));
          if (!(n > 0)) { toast('수량을 넣어 주세요'); return; }
          if (cost > G().pts) { toast('포인트가 모자라요 — 출석하거나 투자 퀴즈를 풀어 포인트를 받아 보세요'); return; }
          const amt = n * cur * rate, w = eq > 0 ? (posVal + amt) / eq * 100 : 0, now = Date.now(), reason = (ui.why || '').trim().slice(0, 60);
          G().pts -= cost;
          let p = P.pos.find(y => y.t === x.t);
          if (p) { p.avg = (p.avg * p.qty + cur * n) / (p.qty + n); p.qty += n; p.buys = (p.buys || 1) + 1; }
          else P.pos.push(p = { t: x.t, n: x.n, mkt: x.mkt, ccy: x.ccy, qty: n, avg: cur, at: now, buys: 1 });
          p.cur = cur; p.cat = now; if (chg != null) p.chg = chg;
          if (reason && !p.why) { p.why = reason; p.whyAt = now; }
          if (!p.review) p.review = now + (ui.rev || r.review) * 86400000;
          P.hist.unshift({ k: 'buy', t: x.t, n: x.n, q: n, p: cur, ccy: x.ccy, at: now, nth: p.buys, why: reason || p.why || '', big: amt > part * 1.5 + 1, over: w > r.max + .5 }); P.hist = P.hist.slice(0, 100);
          if (!inWatch(x.t, x.ccy)) watchlist().push({ ticker: x.t, name: x.n, market: x.mkt, ccy: x.ccy, cur, at: now });
          save(); toast('🎮 ' + x.n + ' ' + n + '주 모의 매수 (-' + nf(cost, 0) + 'P)'); ui.q = null; ui.why = ''; draw(); paperRerender();
        }
      };
    } else {
      const third = Math.max(1, Math.floor(pos.qty / 3)), half = Math.max(1, Math.floor(pos.qty / 2));
      if (ui.q == null) { ui.q = pos.qty >= 3 ? third : pos.qty; ui.part = pos.qty >= 3 ? 't' : 'a'; }
      const days = Math.max(0, Math.round((Date.now() - (pos.whyAt || pos.at || Date.now())) / 86400000));
      const hint = { same: '이유가 그대로라면, 값이 내리거나 오른 것 말고 달라진 게 있는지 한 번 더 살펴보세요.', chg: '이유가 바뀌었다면 처음 판단을 다시 세울 때예요.', unk: '살 때 적은 이유를 지금도 내 말로 설명할 수 있는지 떠올려 보세요.' }[ui.same] || '';
      m.setBody(head +
        '<div class="pp-why"><small>' + (days ? days + '일 전' : '오늘') + ', 살 때 내가 적은 이유</small>' + (pos.why ? '“' + esc(pos.why) + '”' : '<i>이유를 적지 않았어요</i>') + '</div>' +
        '<div class="pp-lb"><span>그 이유가 바뀌었나요?</span></div>' +
        '<div class="chips" id="ppSame">' + [['same', '아니요, 그대로예요'], ['chg', '네, 바뀌었어요'], ['unk', '잘 모르겠어요']].map(o => '<button class="chip' + (ui.same === o[0] ? ' pick' : '') + '" data-s="' + o[0] + '">' + o[1] + '</button>').join('') + '</div>' +
        (hint ? '<p class="pp-mini">' + hint + '</p>' : '') +
        '<div class="pp-lb"><span>나눠 팔기</span></div>' +
        '<div class="pp-plan" id="ppPart">' + (pos.qty >= 3 ? '<span data-q="' + third + '" data-k="t" class="' + (ui.part === 't' ? 'on' : '') + '">1/3만</span>' : '') + (pos.qty >= 2 ? '<span data-q="' + half + '" data-k="h" class="' + (ui.part === 'h' ? 'on' : '') + '">절반</span>' : '') + '<span data-q="' + pos.qty + '" data-k="a" class="' + (ui.part === 'a' ? 'on' : '') + '">전부</span></div>' +
        '<div class="field" style="margin-top:12px"><label>수량 (주)</label><input class="input tnum lg" id="ppQ" inputmode="numeric" value="' + esc(String(ui.q)) + '" placeholder="몇 주?"></div>' +
        '<div class="pp-wt" id="ppSum"></div>' +
        '<div class="row-btns pp-btns" style="margin-top:12px"><button class="btn btn-outline btn-lg" style="flex:1" id="ppToBuy">더 사기</button><button class="btn btn-primary btn-lg" style="flex:2" id="ppSell">팔기</button></div>' + foot);
      const q = m.body.querySelector('#ppQ'), sum = m.body.querySelector('#ppSum'), sellB = m.body.querySelector('#ppSell');
      const upd = () => {
        const n = Math.min(pos.qty, Math.floor(num(q.value)) || 0); ui.q = q.value;
        sellB.textContent = n > 0 ? nf(n, 0) + '주 팔기' : '팔기';
        const gain = Math.round((cur - pos.avg) * n * rate);
        sum.className = 'pp-wt'; sum.innerHTML = n > 0 ? nf(n, 0) + '주 ≈ ' + nf(Math.floor(n * cur * rate * (1 - PAPER_FEE)), 0) + 'P <small>(손익 <b class="' + cls(gain) + '">' + (gain >= 0 ? '+' : '') + nf(gain, 0) + 'P</b>)</small>' : '팔 수 있는 수량: ' + nf(pos.qty, 0) + '주';
      };
      q.oninput = () => { ui.part = ''; m.body.querySelectorAll('#ppPart span').forEach(b => b.classList.remove('on')); upd(); }; upd();
      m.body.onclick = e => {
        const s1 = e.target.closest('#ppSame [data-s]'); if (s1) { ui.same = s1.dataset.s; draw(); return; }
        const pt = e.target.closest('#ppPart [data-q]'); if (pt) { ui.q = pt.dataset.q; ui.part = pt.dataset.k; q.value = pt.dataset.q; m.body.querySelectorAll('#ppPart span').forEach(b => b.classList.toggle('on', b === pt)); upd(); return; }
        if (e.target.closest('#ppToBuy')) { mode = 'buy'; ui.q = null; draw(); return; }
        if (e.target.closest('#ppSell')) {
          const p = P.pos.find(y => y.t === x.t); if (!p) return;
          const n = Math.min(p.qty, Math.floor(num(q.value)) || 0); if (!(n > 0)) { toast('팔 수량을 넣어 주세요'); return; }
          const get = Math.floor(n * cur * rate * (1 - PAPER_FEE)), gain = Math.round((cur - p.avg) * n * rate);
          G().pts += get; P.realized += gain; p.qty -= n; if (p.qty <= 0) P.pos = P.pos.filter(y => y !== p);
          P.hist.unshift({ k: 'sell', t: x.t, n: x.n, q: n, p: cur, ccy: x.ccy, gain, at: Date.now(), why: p.why || '', same: ui.same || '', held: days }); P.hist = P.hist.slice(0, 100);
          save(); toast((gain >= 0 ? '🎉 ' : '') + x.n + ' ' + n + '주 모의 매도 (' + (gain >= 0 ? '+' : '') + nf(gain, 0) + 'P)'); ui.q = null; ui.same = ''; draw(); paperRerender();
        }
      };
    }
  };
  draw();
}
function paperRerender() { if (route.page === 'watch') PAGES.watch({}, true); }
/* 📒 거래 기록 · 성과 · 등급 (v4.2) */
function paperStats() {
  const P = PP(), sells = P.hist.filter(h => h.k === 'sell'), wins = sells.filter(h => h.gain > 0);
  const best = sells.slice().sort((a, b) => b.gain - a.gain)[0], worst = sells.slice().sort((a, b) => a.gain - b.gain)[0];
  const V = paperValue(), tot = V.pl + (P.realized || 0);
  const lv = tot >= 30000000 ? ['🐉 전설', 5] : tot >= 10000000 ? ['🦁 고수', 4] : tot >= 3000000 ? ['🐯 중수', 3] : tot >= 500000 ? ['🐥 초보 탈출', 2] : P.hist.length ? ['🐣 새싹', 1] : ['🥚 시작 전', 0];
  return { trades: P.hist.length, sells: sells.length, wins: wins.length, rate: sells.length ? Math.round(wins.length / sells.length * 100) : null, best, worst, tot, lv };
}
function paperSnap() {                                       // 하루 한 번 모의 계좌 총액 기록 (추이 그래프)
  const P = PP(), d = todayKey(), v = Math.round(G().pts + paperValue().v);
  P.snap = (P.snap || []).filter(x => x.d !== d); P.snap.push({ d, v }); P.snap = P.snap.slice(-60);
}
function paperHistHtml(n) {
  const P = PP(); n = n || 6;
  const rows = P.hist.slice(0, n).map(h => '<div class="pp-h"><span class="k ' + h.k + '">' + (h.k === 'buy' ? '매수' : '매도') + '</span><b>' + esc(h.n) + '</b><span>' + nf(h.q, 0) + '주 · ' + esc(priceTxt(h.p, h.ccy)) + '</span>' +
    (h.k === 'sell' ? '<i class="' + cls(h.gain) + '">' + (h.gain >= 0 ? '+' : '') + nf(Math.round(h.gain), 0) + 'P</i>' : '<i class="muted">' + new Date(h.at).toLocaleDateString('ko-KR', { month: 'numeric', day: 'numeric' }) + '</i>') +
    (h.why ? '<small class="pp-h-why">“' + esc(h.why) + '”' + (h.k === 'sell' && h.same ? ' · 이유 ' + ({ same: '그대로', chg: '바뀜', unk: '모름' }[h.same] || '') : '') + '</small>' : '') + '</div>').join('');
  return rows + (P.hist.length > n ? '<button class="btn btn-ghost btn-sm btn-block" data-act="paper-hist-more">거래 ' + (P.hist.length - n) + '건 더 보기</button>' : '');
}
function paperSellAll() {
  const P = PP(); if (!P.pos.length) return;
  if (!confirm('모의로 들고 있는 ' + P.pos.length + '종목을 지금 시세로 모두 팔까요? (포인트로 돌아와요)')) return;
  let got = 0, gain = 0, skip = 0;
  P.pos.slice().forEach(p => {
    const c = paperCur(p.t); if (!c) { skip++; return; }
    const r = paperRate(p.ccy), g = Math.round((c - p.avg) * p.qty * r), get = Math.floor(p.qty * c * r * (1 - PAPER_FEE));
    G().pts += get; P.realized += g; got += get; gain += g;
    P.hist.unshift({ k: 'sell', t: p.t, n: p.n, q: p.qty, p: c, ccy: p.ccy, gain: g, at: Date.now() });
    P.pos = P.pos.filter(y => y !== p);
  });
  P.hist = P.hist.slice(0, 100); save();
  toast('🎮 모두 팔았어요 · +' + nf(got, 0) + 'P (손익 ' + (gain >= 0 ? '+' : '') + nf(gain, 0) + 'P)' + (skip ? ' · 시세 없는 ' + skip + '종목은 남김' : ''));
  paperRerender();
}
/* v4.41: 간단하게 — 위엔 총 수익·남은 포인트만, 보유 종목 줄에서 바로 [더 사기][팔기], 나머지 숫자·성적·기록은 '자세히 보기'로 접음 */
function paperCardHtml() {
  if (!feat('paper')) return '';
  const P = PP(), V = paperValue(), g = G(), w = watchlist();
  try { paperSnap(); } catch (e) {}
  const ST = paperStats();
  const sg = v => (v >= 0 ? '+' : '') + nf(Math.round(v), 0);
  const tot = V.pl + (P.realized || 0), totPct = V.cost > 0 ? V.pl / V.cost * 100 : null;
  const last = Math.max(0, ...P.pos.map(p => p.cat || 0));
  const when = last ? (Date.now() - last < 90000 ? '방금' : new Date(last).toTimeString().slice(0, 5)) + ' 시세 기준' : '시세 확인 전';
  const RON = rulesOn(), RR = RON ? RU() : null;
  const rows = P.pos.map(p => {
    const c = paperCur(p.t), r = paperRate(p.ccy), px = c || p.avg, pl = (px - p.avg) * p.qty * r;
    const dchg = c && p.chg != null && isFinite(p.chg) ? '<em class="' + cls(p.chg) + '">오늘 ' + pct(p.chg) + '</em>' : '';
    const pay = m => esc(JSON.stringify(Object.assign({ ticker: p.t, name: p.n, market: p.mkt, ccy: p.ccy }, m ? { mode: m } : {})));
    return '<div class="pp-row2"><div class="pp-r-top"><div class="mid"><b>' + esc(p.n) + ' ' + dchg + '</b>' +
      '<span>' + nf(p.qty, 0) + '주 · 평균 ' + esc(priceTxt(p.avg, p.ccy)) + ' → 지금 ' + (c ? esc(priceTxt(c, p.ccy)) : '<i>시세 대기</i>') + (RON ? ' · ' + RR.split + '번 중 ' + Math.min(p.buys || 1, 99) + '번 삼' : '') + '</span></div>' +
      '<b class="' + cls(pl) + '">' + sg(pl) + 'P<br><small>' + pct((px / p.avg - 1) * 100) + '</small></b></div>' +
      (RON ? ((p.why ? '<div class="pp-r-why">“' + esc(p.why) + '”</div>' : '') + (p.review && p.review <= Date.now() ? '<button class="pp-r-due" data-act="paper-review" data-t="' + esc(p.t) + '">🔔 다시 볼 때예요 · 산 이유가 그대로인지 보기</button>' : '')) : '') +
      '<div class="pp-r-btns"><button class="btn btn-soft btn-sm" data-act="paper" data-p="' + pay() + '">더 사기</button>' +
      '<button class="btn btn-outline btn-sm" data-act="paper" data-p="' + pay('sell') + '">팔기</button></div></div>';
  }).join('');
  const hero = P.pos.length || P.realized ?
    '<div class="pp-hero ' + (tot > 0 ? 'is-up' : tot < 0 ? 'is-dn' : '') + '">' +
      '<div class="pp-h-l">모의투자 총 ' + (tot > 0 ? '수익' : tot < 0 ? '손실' : '손익') + ' <span>(들고 있는 것 + 이미 판 것)</span></div>' +
      '<div class="pp-h-v ' + cls(tot) + '">' + sg(tot) + '<small>P</small></div>' +
      '<div class="pp-h-s">' + (totPct != null ? '보유 종목 <b class="' + cls(V.pl) + '">' + pct(totPct) + '</b>' : '보유 종목 없음') +
        (V.day ? ' · 오늘 <b class="' + cls(V.day) + '">' + sg(V.day) + 'P</b>' : '') +
        ' <span class="pp-when">⏱ ' + esc(when) + (V.stale ? ' · ' + V.stale + '종목 시세 대기' : '') + '</span></div></div>' : '';
  const buyChips = w.length ? '<div class="ah-sub">관심종목에서 골라 사 보기</div><div class="chips">' + w.slice(0, 16).map(x => '<button class="chip" data-act="paper" data-p="' + esc(JSON.stringify({ ticker: x.ticker, name: dispName(x), market: x.market, ccy: x.ccy, cur: x.cur })) + '">🎮 ' + esc(dispName(x)) + '</button>').join('') + '</div>'
    : '<p class="note" style="margin:8px 0 0">관심종목 탭에서 종목을 담으면 여기서 포인트로 사 볼 수 있어요.</p>';
  const more = P.pos.length || P.hist.length ?
    '<details class="fold pp-more" id="ppMore"' + (_ppMore ? ' open' : '') + '><summary>자세히 보기 · 손익 내역 · 내 성적 · 거래 기록</summary>' +
      '<div class="pp-kpi"><div><span>주식 평가</span><b>' + nf(Math.round(V.v), 0) + '</b></div><div><span>산 돈</span><b>' + nf(Math.round(V.cost), 0) + '</b></div>' +
        '<div><span>평가 손익 (들고 있는 것)</span><b class="' + cls(V.pl) + '">' + sg(V.pl) + '</b></div><div><span>실현 손익 (이미 판 것)</span><b class="' + cls(P.realized) + '">' + sg(P.realized || 0) + '</b></div></div>' +
      '<div class="pp-grade g3"><div><span>내 등급</span><b>' + ST.lv[0] + '</b></div><div><span>거래</span><b>' + ST.trades + '회</b></div><div><span>승률</span><b>' + (ST.rate == null ? '-' : ST.rate + '%') + '</b><small>' + ST.wins + '/' + ST.sells + '</small></div>' +
        '<div><span>최고 거래</span><b>' + (ST.best && ST.best.gain > 0 ? '<i class="up">+' + nf(Math.round(ST.best.gain), 0) + '</i>' : '-') + '</b></div>' +
        '<div><span>최악 거래</span><b>' + (ST.worst && ST.worst.gain < 0 ? '<i class="down">' + nf(Math.round(ST.worst.gain), 0) + '</i>' : '-') + '</b></div></div>' +
      ((P.snap || []).length >= 2 ? '<div class="pp-trend"><span>모의 계좌 총액 추이 (' + P.snap.length + '일)</span>' + sparkline(P.snap.map(x => x.v), { h: 36 }) + '</div>' : '') +
      (P.hist.length ? '<div class="ah-sub">📒 거래 기록</div><div class="pp-hist">' + paperHistHtml(6) + '</div>' : '') +
    '</details>' : '';
  return rulesCardHtml() + '<div class="card pp-card" style="margin-bottom:16px">' + hero +
    '<div class="pp-kpi"><div><span>남은 포인트</span><b>💎 ' + nf(g.pts, 0) + '</b></div><div><span>모의 계좌 총액</span><b>' + nf(Math.round(g.pts + V.v), 0) + '</b></div></div>' +
    (rows ? '<div class="pp-sec"><b>보유 종목 ' + P.pos.length + '</b>' + (P.pos.length >= 2 ? '<button class="btn btn-ghost btn-sm" data-act="paper-sell-all">모두 팔기</button>' : '') + '</div><div class="pp-list">' + rows + '</div>'
          : '<p class="note" style="margin:6px 0">아직 모의로 산 종목이 없어요. 아래에서 골라 포인트로 사 보세요.</p>') +
    buyChips + more +
    '<p class="note" style="margin:12px 0 0">연습용이에요 (1P = 1원 · 실제 돈·주문 아님). 시세는 15~20분 늦을 수 있어요.' +
      (g.pts < 10000 ? ' 포인트가 부족하면 출석하거나 <a class="lnk" data-nav="game">투자 퀴즈</a>를 풀어 받으세요.' : '') + '</p></div>';
}

// 관심종목 카드에 '포인트로 산 것' 표시 — 실제 보유와 헷갈리지 않게
function paperBadge(t) {
  if (!feat('paper')) return '';
  const p = PP().pos.find(x => x.t === String(t || '').toUpperCase());
  return p ? '<em class="pp-badge" title="포인트로 산 모의 보유">🎮 모의 ' + nf(p.qty, 0) + '주</em>' : '';
}
