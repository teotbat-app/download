#!/bin/bash
# ==========================================================================
#  맥(macOS)용 설치 스크립트 — "설치하기.command" 가 이 파일을 실행합니다.
#
#  하는 일
#    1) 프로그램 파일을 홈 폴더의 "응용 프로그램"(~/Applications) 아래로 옮겨 둡니다.
#       → 다운로드 폴더를 정리해도 앱이 그대로 남아요.
#    2) 그 폴더 안(app/runtime/python)에 '휴대용 파이썬'을 내려받습니다.
#       → 컴퓨터에 따로 설치하지 않으므로 관리자 암호가 필요 없어요.
#    3) 앱에 필요한 부품(flask 등)을 설치합니다.
#    4) "응용 프로그램"과 바탕화면에 앱 아이콘을 만들고, 그 아이콘으로 앱이 실제로 켜지는지 확인합니다.
#       (아이콘 방식이 맞지 않는 맥이면 바탕화면에 "… 실행.command" 를 대신 만듭니다)
#  인터넷이 필요합니다(약 25MB). 다시 실행해도 안전합니다(자산 데이터는 건드리지 않음).
#
#  시험용 환경변수(평소엔 쓰지 않음): ASSET_INSTALL_BASE=설치할 곳 · ASSET_NO_LAUNCH=1 · ASSET_NO_DESKTOP=1
#  맥의 기본 bash(3.2)에서 돌아가야 하므로 새 문법은 쓰지 않습니다.
# ==========================================================================
set -u

PY_VER="3.12.10"
PBS_TAG="20250409"
SHA_MAC_ARM="0be1fe0b35a4d3c382141764ef16ed3b8cc2b4620b657f678daa7b7f8df39699"
SHA_MAC_X64="ad3bef94b6054adcf8e0a47886e21b00dfc6a37f22eea229cf0f8725bd0e1023"
SHA_LINUX_X64="8c59b9ac6bff2dc3934181d7bc82594f9f59a613afed8d72c9e89d7194e790ee"
PORT=8000
TOTAL=4
export PYTHONNOUSERSITE=1                             # 이 컴퓨터에 따로 깔린 파이썬 부품과 섞이지 않게
unset PYTHONHOME PYTHONPATH

if [ -t 1 ]; then
    C_B=$'\033[1;34m'; C_G=$'\033[1;32m'; C_Y=$'\033[33m'; C_R=$'\033[1;31m'; C_D=$'\033[2m'; C_0=$'\033[0m'
else
    C_B=""; C_G=""; C_Y=""; C_R=""; C_D=""; C_0=""
fi
say()  { printf '%s\n' "$1"; }
step() { printf '\n%s[%s/%s] %s%s\n' "$C_B" "$1" "$TOTAL" "$2" "$C_0"; }
ok()   { printf '      %s[OK]%s %s\n' "$C_G" "$C_0" "$1"; }
warn() { printf '      %s%s%s\n' "$C_Y" "$1" "$C_0"; }
fail() {
    printf '\n%s  ================================================%s\n' "$C_R" "$C_0"
    printf '%s  설치하지 못했어요: %s%s\n' "$C_R" "$1" "$C_0"
    printf '%s  ================================================%s\n\n' "$C_R" "$C_0"
    printf '%s  • 인터넷이 연결되어 있는지 확인한 뒤 다시 설치해 주세요.%s\n' "$C_Y" "$C_0"
    printf '%s  • 회사·학교 컴퓨터는 보안 프로그램이 내려받기를 막을 수 있어요.%s\n' "$C_Y" "$C_0"
    printf '%s  • 계속 안 되면 이 창의 내용을 사진으로 찍어 배포한 분께 보내 주세요.%s\n\n' "$C_Y" "$C_0"
    exit 1
}

SELF_DIR="$(cd "$(dirname "$0")" && pwd)"            # …/app/tools/mac
SRC_APP="$(cd "$SELF_DIR/../.." && pwd)"             # …/app
SRC_TOP="$(cd "$SRC_APP/.." && pwd)"                 # 겉 폴더(압축을 푼 곳)

ED="$(head -n 1 "$SRC_APP/edition.txt" 2>/dev/null | tr -d ' \t\r\n' | tr 'A-Z' 'a-z')"
if [ "$ED" = "tb" ]; then
    APP_NAME="텃밭투자집사"; FOLDER="TeotbatFiles"
else
    APP_NAME="내 투자 비서"; FOLDER="MyInvestFiles"
fi

OS="$(uname -s)"; ARCH="$(uname -m)"
case "$OS" in
    Darwin)
        if [ "$ARCH" = "arm64" ] || [ "$(sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ]; then
            TRIPLE="aarch64-apple-darwin"; PY_SHA="$SHA_MAC_ARM"
        else
            TRIPLE="x86_64-apple-darwin"; PY_SHA="$SHA_MAC_X64"
        fi ;;
    Linux)                                            # 만든 사람이 시험할 때만 쓰는 갈래
        TRIPLE="x86_64-unknown-linux-gnu"; PY_SHA="$SHA_LINUX_X64"
        [ "$ARCH" = "x86_64" ] || TRIPLE="" ;;
    *)  TRIPLE="" ;;
esac

BASE="${ASSET_INSTALL_BASE:-$HOME/Applications}"
DEST="$BASE/$FOLDER"
DEST_APP="$DEST/app"
RUNTIME="$DEST_APP/runtime"
PYDIR="$RUNTIME/python"
VENV="$RUNTIME/venv"

[ -t 1 ] && clear
say ""
say "${C_B}  ================================================${C_0}"
say "${C_B}        $APP_NAME  -  설치를 시작합니다${C_0}"
say "${C_B}  ================================================${C_0}"
say ""
say "  창을 닫지 말고 잠시 기다려 주세요. (보통 1~3분)"
say "${C_D}  설치 위치: $DEST${C_0}"

[ -r "$SRC_APP/price_server.py" ] || fail "프로그램 파일을 읽지 못했어요. 압축을 다시 풀어서 해 보세요."

# ---------------------------------------------------------------- 1. 파일 옮기기
step 1 "프로그램 파일 준비"
NEW_BASE=0
[ -d "$BASE" ] || NEW_BASE=1
if [ -f "$DEST_APP/price_server.py" ]; then           # 이미 깔려 있고 켜져 있으면, 손대기 전에 끔 (끝나면 새로 켬)
    curl -s --noproxy '*' -m 3 "http://127.0.0.1:$PORT/shutdown" >/dev/null 2>&1 && sleep 1
fi
if ! [ "$SRC_APP" -ef "$DEST_APP" ]; then            # 같은 폴더인지는 글자가 아니라 실제 위치로 비교
    mkdir -p "$DEST_APP" || fail "설치할 폴더를 만들지 못했어요: $DEST"
    # 홈의 "응용 프로그램" 폴더를 새로 만든 경우, Finder 에 한글 이름(응용 프로그램)으로 보이게 함
    if [ "$NEW_BASE" = "1" ] && [ "$OS" = "Darwin" ]; then touch "$BASE/.localized" 2>/dev/null; fi
    # 자산 데이터(userdata)·휴대용 파이썬(runtime)·백업은 그대로 두고, 프로그램 파일만 새 것으로 바꿈
    for item in "$SRC_APP"/*; do
        [ -e "$item" ] || continue
        name="$(basename "$item")"
        case "$name" in userdata|runtime|_backup|_update|__pycache__) continue ;; esac
        rm -rf "${DEST_APP:?}/$name"
        cp -R "$item" "$DEST_APP/" || fail "프로그램 파일을 옮기지 못했어요: $name"
    done
    for item in "$SRC_TOP"/*.txt; do
        [ -f "$item" ] && cp "$item" "$DEST/" 2>/dev/null
    done
    ok "프로그램 파일을 옮겼어요"
else
    ok "이미 설치 위치에 있어요"
fi
chmod 755 "$DEST_APP"/tools/mac/*.sh 2>/dev/null
# 인터넷에서 받은 파일에 붙는 '격리' 표시를 미리 떼어 둠 (아이콘을 눌렀을 때 경고가 뜨지 않게)
[ "$OS" = "Darwin" ] && xattr -dr com.apple.quarantine "$DEST" >/dev/null 2>&1

# ---------------------------------------------------------------- 2. 파이썬
step 2 "휴대용 파이썬 준비"
test_py() {
    [ -x "$1" ] && "$1" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' >/dev/null 2>&1
}
get_file() {   # $1 주소  $2 받을 곳
    curl -fL --retry 3 --retry-delay 3 --connect-timeout 20 -m 900 -sS -o "$2" "$1" && [ -s "$2" ]
}
sha_ok() {     # $1 파일  $2 기대값 — 확인 도구가 없으면 통과
    local got=""
    if command -v shasum >/dev/null 2>&1; then got="$(shasum -a 256 "$1" 2>/dev/null | awk '{print $1}')"
    elif command -v sha256sum >/dev/null 2>&1; then got="$(sha256sum "$1" 2>/dev/null | awk '{print $1}')"
    else return 0; fi
    [ "$got" = "$2" ]
}
find_system_python() {
    local c p
    for c in python3.13 python3.12 python3.11 python3.10 python3 /opt/homebrew/bin/python3 /usr/local/bin/python3; do
        p="$(command -v "$c" 2>/dev/null)"
        [ -n "$p" ] || continue
        # 맥의 /usr/bin/python3 는 개발 도구가 없으면 '설치하시겠습니까' 창만 띄우므로 건너뜀
        if [ "$p" = "/usr/bin/python3" ] && [ "$OS" = "Darwin" ] && ! xcode-select -p >/dev/null 2>&1; then continue; fi
        if test_py "$p"; then printf '%s\n' "$p"; return 0; fi
    done
    return 1
}

PY=""
if test_py "$PYDIR/bin/python3"; then
    PY="$PYDIR/bin/python3"; ok "이미 준비되어 있어요"
elif test_py "$VENV/bin/python3"; then
    PY="$VENV/bin/python3"; ok "이미 준비되어 있어요"
else
    mkdir -p "$RUNTIME" || fail "설치 폴더에 쓸 수 없어요: $RUNTIME"
    TGZ="$RUNTIME/python.tar.gz"
    GOT=0
    if [ -n "$TRIPLE" ]; then
        say "      Python $PY_VER 내려받는 중… (약 16MB)"
        URL="https://github.com/astral-sh/python-build-standalone/releases/download/$PBS_TAG/cpython-$PY_VER%2B$PBS_TAG-$TRIPLE-install_only_stripped.tar.gz"
        if get_file "$URL" "$TGZ"; then
            if sha_ok "$TGZ" "$PY_SHA"; then GOT=1; else warn "내려받은 파일이 원본과 달라서 쓰지 않았어요."; fi
        fi
    fi
    if [ "$GOT" = "1" ]; then
        rm -rf "$PYDIR"
        tar -xzf "$TGZ" -C "$RUNTIME" || fail "내려받은 파이썬 압축을 풀지 못했어요."
        rm -f "$TGZ"
        PY="$PYDIR/bin/python3"
        test_py "$PY" || fail "내려받은 파이썬이 실행되지 않아요."
        ok "휴대용 파이썬 준비 완료"
    else
        rm -f "$TGZ"
        warn "내려받기가 안 돼서, 이 컴퓨터에 이미 있는 파이썬을 찾아볼게요…"
        SYS="$(find_system_python)" || fail "파이썬을 내려받지 못했고, 컴퓨터에 설치된 파이썬(3.9 이상)도 없어요."
        "$SYS" -m venv "$VENV" >/dev/null 2>&1
        PY="$VENV/bin/python3"
        test_py "$PY" || fail "파이썬 가상환경을 만들지 못했어요."
        ok "컴퓨터의 파이썬 사용: $SYS"
    fi
fi

# ---------------------------------------------------------------- 3. 부품
step 3 "앱 부품 설치 (flask · requests · beautifulsoup4)"
"$PY" -m pip --version >/dev/null 2>&1 || "$PY" -m ensurepip --upgrade >/dev/null 2>&1
"$PY" -m pip --version >/dev/null 2>&1 || fail "부품 설치 도구(pip)를 준비하지 못했어요."
if ! "$PY" -m pip install -r "$DEST_APP/requirements.txt" --no-warn-script-location --disable-pip-version-check -q; then
    warn "한 번 더 시도할게요…"
    "$PY" -m pip install -r "$DEST_APP/requirements.txt" --no-warn-script-location --disable-pip-version-check || fail "앱 부품을 설치하지 못했어요."
fi
"$PY" -c "import flask, flask_cors, requests, bs4" >/dev/null 2>&1 || fail "설치한 부품을 불러오지 못했어요."
ok "부품 설치 완료"

# ---------------------------------------------------------------- 4. 아이콘
step 4 "앱 아이콘 만들기"
APP_ICON="$BASE/$APP_NAME.app"                        # 응용 프로그램 폴더의 아이콘(작은 앱)
DESK_LINK="$HOME/Desktop/$APP_NAME"                   # 바탕화면에서 그 아이콘을 가리키는 바로가기
DESK_CMD="$HOME/Desktop/$APP_NAME 실행.command"        # 아이콘 방식이 안 될 때 대신 쓰는 파일

port_up() { curl -sf --noproxy '*' -o /dev/null -m 2 "http://127.0.0.1:$PORT/api/status" 2>/dev/null; }
wait_up() {    # $1 = 몇 번(0.5초씩) 기다릴지
    local i=0
    while [ "$i" -lt "$1" ]; do
        if port_up; then return 0; fi
        sleep 0.5
        i=$((i + 1))
    done
    return 1
}
write_cmd() {  # $1 만들 파일  $2 부를 스크립트  $3 붙일 말 — 설치 폴더 안에서 쓰는 실행 파일
    printf '#!/bin/bash\nDIR="$(cd "$(dirname "$0")" && pwd)"\nexec /bin/bash "$DIR/app/tools/mac/%s" %s\n' "$2" "$3" > "$1" && chmod 755 "$1"
}
esc_as() {     # 애플스크립트 글자열 안에 넣을 수 있게 \ 와 " 앞에 \ 를 붙임
    printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'
}
is_ours() {    # $1 = .app — 이 설치가 만든 아이콘인지 (안에 넣어 둔 표시로 확인)
    [ -f "$1/Contents/Resources/asset-install.txt" ]
}
make_app() {   # $1 = 만들 .app 경로. 맥에 기본으로 들어 있는 osacompile 로 '누르면 run.sh 를 부르는 작은 앱'을 만듦
    # (셸 스크립트만 넣은 앱은 애플 칩 맥에서 '인텔용 앱'으로 여겨져 로제타를 요구하므로, 진짜 실행 파일이 든 앱으로 만듦)
    local app="$1" tmp="${DEST:?}/.icon-build" built
    [ "$OS" = "Darwin" ] || return 1
    command -v osacompile >/dev/null 2>&1 || return 1
    case "$app" in *.app) ;; *) return 1 ;; esac
    if [ -e "$app" ] && ! is_ours "$app"; then return 1; fi          # 이름만 같은 다른 앱이면 건드리지 않음
    rm -rf "$tmp"
    mkdir -p "$tmp" || return 1
    built="$tmp/$APP_NAME.app"                                        # 다른 곳에서 다 만든 뒤 한 번에 옮김
    osacompile -o "$built" -e "do shell script \"/bin/bash \" & quoted form of \"$(esc_as "$DEST_APP/tools/mac/run.sh")\" & \" >/dev/null 2>&1 &\"" >/dev/null 2>&1
    if [ ! -f "$built/Contents/Info.plist" ]; then rm -rf "$tmp"; return 1; fi
    if [ -f "$DEST_APP/assets/app.icns" ]; then
        cp "$DEST_APP/assets/app.icns" "$built/Contents/Resources/applet.icns" 2>/dev/null
        rm -f "$built/Contents/Resources/Assets.car"                  # 새 맥OS는 여기 든 기본 그림을 먼저 써서, 지워야 우리 그림이 보임
        plutil -remove CFBundleIconName "$built/Contents/Info.plist" >/dev/null 2>&1
    fi
    printf '%s\n' "$DEST_APP" > "$built/Contents/Resources/asset-install.txt"
    codesign --force --deep -s - "$built" >/dev/null 2>&1             # 그림을 바꿨으니 이 컴퓨터용 서명을 다시 함 (안 돼도 계속)
    rm -rf "$app"
    if ! mv "$built" "$app"; then rm -rf "$tmp"; return 1; fi
    rm -rf "$tmp"
    touch "$app"
    return 0
}
drop_app() {   # 만든 아이콘을 치움 (아이콘 방식이 이 맥에서 안 될 때)
    if is_ours "$APP_ICON"; then rm -rf "$APP_ICON"; fi
    if [ -L "$DESK_LINK" ]; then rm -f "$DESK_LINK"; fi
}

write_cmd "$DEST/$APP_NAME 실행.command" "run.sh" ""
write_cmd "$DEST/문제 해결용 실행.command" "run.sh" "--debug"
write_cmd "$DEST/삭제하기.command" "uninstall.sh" ""
write_cmd "$DEST/다시 설치하기.command" "install.sh" ""

HAS_APP=0
STARTED=0
BUSY=0
if port_up; then BUSY=1; fi
if make_app "$APP_ICON"; then
    HAS_APP=1
    if [ -z "${ASSET_NO_LAUNCH:-}" ] && [ "$BUSY" = "0" ]; then
        say "      아이콘으로 앱을 켜 보는 중… (처음에는 10초쯤 걸려요)"
        open "$APP_ICON" >/dev/null 2>&1
        if wait_up 80; then
            STARTED=1
        else
            HAS_APP=0
            drop_app
            warn "이 맥에서는 아이콘 방식이 맞지 않아, 다른 방식으로 바꿀게요."
        fi
    fi
fi

if [ "$HAS_APP" = "1" ]; then
    ok "응용 프로그램에 아이콘 완료 (Spotlight 에서 \"$APP_NAME\" 로 찾을 수 있어요)"
    if [ -z "${ASSET_NO_DESKTOP:-}" ] && [ -d "$HOME/Desktop" ]; then
        if [ -L "$DESK_LINK" ]; then rm -f "$DESK_LINK"; fi
        if [ ! -e "$DESK_LINK" ] && ln -s "$APP_ICON" "$DESK_LINK" 2>/dev/null; then
            ok "바탕화면 아이콘 완료"
        else
            warn "바탕화면 아이콘은 만들지 못했어요. Spotlight(⌘+스페이스)에서 \"$APP_NAME\" 를 찾아 주세요."
        fi
        rm -f "$DESK_CMD" 2>/dev/null
    fi
    HOW="바탕화면의 \"$APP_NAME\" 아이콘을"
else
    HOW="설치 폴더의 \"$APP_NAME 실행.command\" 를"
    if [ -z "${ASSET_NO_DESKTOP:-}" ] && [ -d "$HOME/Desktop" ]; then
        if printf '#!/bin/bash\nexec /bin/bash "%s/tools/mac/run.sh"\n' "$DEST_APP" > "$DESK_CMD" 2>/dev/null && chmod 755 "$DESK_CMD"; then
            ok "바탕화면에 \"$APP_NAME 실행\" 파일 완료"
            HOW="바탕화면의 \"$APP_NAME 실행\" 파일을"
        else
            warn "바탕화면에는 만들지 못했어요. 설치 폴더의 \"$APP_NAME 실행.command\" 를 쓰세요."
        fi
    else
        ok "설치 폴더에 \"$APP_NAME 실행.command\" 완료"
    fi
fi

# ---------------------------------------------------------------- 끝
say ""
say "${C_G}  ================================================${C_0}"
say "${C_G}              설치가 끝났어요!${C_0}"
say "${C_G}  ================================================${C_0}"
say ""
say "  ▶ 다음부터는 $HOW 두 번 누르면 돼요."
say "  ▶ 앱을 끌 때는 앱 왼쪽 아래 [종료] 버튼을 누르세요."
say "  ▶ 받았던 압축 파일과 풀린 폴더는 지워도 괜찮아요."
say "${C_D}  ▶ 프로그램과 내 자산 데이터가 있는 곳: $DEST${C_0}"
say ""
if [ -z "${ASSET_NO_LAUNCH:-}" ]; then
    if [ "$STARTED" = "1" ]; then
        say "  앱이 켜졌어요. (인터넷 창이 열려요)"
    elif [ "$BUSY" = "1" ]; then
        warn "지금 다른 앱(또는 이 앱의 다른 판)이 같은 자리(8000번)를 쓰고 있어요. 그 앱을 [종료]한 뒤 켜 주세요."
    else
        say "  지금 앱을 엽니다… (인터넷 창이 열려요)"
        /bin/bash "$DEST_APP/tools/mac/run.sh" </dev/null
    fi
fi
say ""
say "${C_D}  이 창은 닫으셔도 돼요.${C_0}"
exit 0
