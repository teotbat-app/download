#!/bin/bash
# ==========================================================================
#  삭제 (맥) — "삭제하기.command" 가 이 파일을 실행합니다.
#  앱 아이콘과 휴대용 파이썬(runtime 폴더)을 지웁니다.
#  자산 데이터(userdata 폴더)는 물어본 뒤에만 지웁니다.
# ==========================================================================
APP="$(cd "$(dirname "$0")/../.." 2>/dev/null && pwd)"   # …/app
PORT=8000

# 진짜 설치 폴더에서 불렸을 때만 진행 (엉뚱한 곳의 폴더를 지우지 않게)
if [ -z "$APP" ] || [ "$(basename "$APP")" != "app" ] || [ ! -f "$APP/price_server.py" ] || [ ! -f "$APP/edition.txt" ] || [ ! -f "$APP/tools/mac/uninstall.sh" ]; then
    printf '\n  설치 폴더가 아니에요. 설치 폴더의 "삭제하기.command" 로 실행해 주세요.\n\n'
    exit 1
fi
TOP="$(cd "$APP/.." && pwd)"
BASE="$(dirname "$TOP")"

ED="$(head -n 1 "$APP/edition.txt" 2>/dev/null | tr -d ' \t\r\n' | tr 'A-Z' 'a-z')"
if [ "$ED" = "tb" ]; then APP_NAME="텃밭투자집사"; FOLDER="TeotbatFiles"; else APP_NAME="내 투자 비서"; FOLDER="MyInvestFiles"; fi

printf '\n  ================================================\n'
printf '        %s  -  삭제\n' "$APP_NAME"
printf '  ================================================\n\n'

# 켜져 있으면 끄기
curl -s --noproxy '*' -m 3 "http://127.0.0.1:$PORT/shutdown" >/dev/null 2>&1 && sleep 1

# 이 설치 폴더를 가리키는 아이콘만 지움 (이름이 같은 다른 앱을 건드리지 않게, 안에 넣어 둔 표시를 확인)
ICON="$BASE/$APP_NAME.app"
MARK="$ICON/Contents/Resources/asset-install.txt"
DESK_LINK="$HOME/Desktop/$APP_NAME"
DESK_CMD="$HOME/Desktop/$APP_NAME 실행.command"
if [ -L "$DESK_LINK" ] && [ "$(readlink "$DESK_LINK" 2>/dev/null)" = "$ICON" ]; then
    rm -f "$DESK_LINK" && printf '  [OK] 바탕화면 아이콘 삭제\n'
fi
if [ -f "$DESK_CMD" ] && grep -q -F "\"$APP/tools/mac/run.sh\"" "$DESK_CMD" 2>/dev/null; then
    rm -f "$DESK_CMD" && printf '  [OK] 바탕화면 실행 파일 삭제\n'
fi
if [ -f "$MARK" ] && [ "$(head -n 1 "$MARK" 2>/dev/null)" = "$APP" ]; then
    rm -rf "$ICON" && printf '  [OK] 아이콘 삭제: %s\n' "$ICON"
fi

if [ -d "$APP/runtime" ]; then
    rm -rf "$APP/runtime" && printf '  [OK] 휴대용 파이썬 삭제\n'
fi

ALL=0
if [ -d "$APP/userdata" ]; then
    printf '\n  자산 데이터(가족·계좌·기록)와 AI 키가 userdata 폴더에 남아 있어요.\n'
    printf '  이것도 지울까요? 지우면 되돌릴 수 없어요. (지우려면 y 입력 후 Enter) '
    ans=""
    if [ -t 0 ]; then read -r ans; else { read -r ans </dev/tty; } 2>/dev/null; fi
    case "$ans" in
        y*|Y*|ㅛ*) ALL=1 ;;
        *) printf '\n  자산 데이터는 남겨 두었어요. 다시 설치하면 그대로 이어서 쓸 수 있어요.\n  (남은 곳: %s)\n' "$APP/userdata" ;;
    esac
else
    ALL=1
fi

if [ "$ALL" = "1" ]; then
    if [ "$(basename "$TOP")" = "$FOLDER" ]; then
        cd / && rm -rf "$TOP" && printf '  [OK] 프로그램 파일과 자산 데이터 삭제\n'
    elif [ -d "$APP/userdata" ]; then
        rm -rf "$APP/userdata" && printf '  [OK] 자산 데이터 삭제\n'
    fi
fi

printf '\n  삭제가 끝났어요. 이 창은 닫으셔도 돼요.\n\n'
exit 0
