#!/bin/bash
DIR="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
if [ -z "$DIR" ] || [ ! -r "$DIR/app/tools/mac/install.sh" ]; then
    echo ""
    echo "  설치 파일을 읽지 못했어요."
    echo "  · 이 파일을 폴더에서 꺼내지 말고, 압축을 푼 폴더 안에서 그대로 눌러 주세요."
    echo "  · '터미널이 다운로드 폴더의 파일에 접근하려고 합니다' 창에서는 '허용'을 눌러 주세요."
    echo "  · 그래도 안 되면 사용설명서의 '가장 쉬운 방법(한 줄 붙여넣기)'으로 설치해 주세요."
    echo ""
    exit 1
fi
exec /bin/bash "$DIR/app/tools/mac/install.sh"
