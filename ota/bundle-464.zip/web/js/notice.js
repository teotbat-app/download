/* ==========================================================================
   notice.js — 🌱 텃밭 새 소식 안내 (v4.57 · v4.59 · 텃밭투자집사 전용)
   · 앱을 켤 때마다 화면 가득 뜨는 안내: 임시 텃밭 게시판 · 투자 퀴즈 · AI 는 투자 DNA 에서
     (다른 앱에 3분 넘게 있다가 돌아올 때도 — 시작 애니메이션이 다시 나오는 때와 같음)
   · 아래 '다시 보지 않기'를 체크하고 닫으면 이 기기에서는 다시 안 뜸. 체크 없이 닫으면 다음에 켤 때 또 뜸
   · 닫는 법: 오른쪽 위 X · 아래 '닫기' · 각 칸의 바로 가기 버튼 · Esc · 폰 뒤로가기
   · 시작 애니메이션·약관 동의·이용권 잠금이 끝난 뒤에 뜨고, 그동안 다른 첫 안내(AI 켜기 도우미·설문·후원 안내)는 기다림
   · 새 소식을 또 알리려면 TB_NOTICE_ID 를 바꾸고 tbNoticeHtml() 내용을 고치면 됨
   ========================================================================== */
'use strict';

const TB_NOTICE_ID = 'n2611';                     // 2026-11: 게시판·퀴즈·투자 DNA
let _tbnShown = false;                            // 이번에 켠 동안 이미 보여 주고 닫았는지 (앱을 다시 켜면 처음부터)

function tbNoticePending() {                      // 이번에 보여 줄 안내가 남았는지 (다른 첫 안내가 기다리는 데 씀)
  return typeof ED !== 'undefined' && ED === 'tb' && UI.tbNoticeOff !== TB_NOTICE_ID && !_tbnShown;
}

function tbNoticeHtml() {
  const phone = !!(window.matchMedia && window.matchMedia('(max-width: 1023px)').matches);   // 아래 탭이 보이는 화면
  const where = (ph, pc) => '<div class="tbn-where"><span>들어가는 곳</span><b>' + (phone ? ph : pc) + '</b></div>';
  const card = (emo, title, desc, whereHtml, btnAct, btnTxt, extra) =>
    '<section class="tbn-card"><div class="tbn-emo">' + emo + '</div><div class="tbn-body">' +
      '<h3>' + title + '</h3><p>' + desc + '</p>' + (extra || '') + whereHtml +
      '<button class="btn btn-primary tbn-go" data-tbn="' + btnAct + '">' + btnTxt + '</button></div></section>';
  const aiOff = !(typeof AI_STATUS !== 'undefined' && AI_STATUS && AI_STATUS.on);
  let h = '';
  if (typeof feat === 'function' && feat('board')) h += card('💬', '임시 텃밭 게시판이 열렸어요',
    '텃밭 식구끼리 <b>별명</b>으로 이야기 나누는 곳이에요. 궁금한 점이나 <b>앱 건의</b>도 여기에 남겨 주세요.',
    where('아래 <em>더보기</em> → <em>임시 텃밭 게시판</em>', '왼쪽 메뉴 → <em>텃밭 게시판</em>'),
    'board', '게시판 가 보기',
    '<p class="tbn-small">연락처·링크·종목 추천 글은 올릴 수 없어요.</p>');
  h += card('🧠', '투자 퀴즈가 열렸어요',
    '하루 <b>3문제</b>, 네 개 중 하나를 골라요. 다섯 단계 중 <b>내 수준</b>을 고를 수 있고, 맞히면 포인트를 받아 <b>모의투자</b>에 써요.',
    where('아래 <em>퀴즈</em> 탭', '왼쪽 메뉴 → <em>퀴즈 · 로또</em>'),
    'quiz', '오늘의 퀴즈 풀기');
  if (typeof feat === 'function' && feat('dna')) h += card('🧬', 'AI는 ‘투자 DNA’에서 나에게 맞게 설정해요',
    '성격·투자금·버틸 수 있는 손실, 차트·뉴스를 얼마나 보는지 정해 두면 <b>모든 AI 분석과 대화</b>가 그 기준으로 답해요.',
    where('아래 <em>AI</em> 탭 → <em>투자 DNA</em>', '왼쪽 메뉴 <em>AI 비서</em> → <em>투자 DNA</em>'),
    'dna', '투자 DNA 열기',
    aiOff ? '<p class="tbn-small">AI를 아직 안 켰다면 ' + (phone ? '<b>AI</b> 탭에서' : '왼쪽 아래 <b>AI 연결하기 (무료)</b>에서') + ' 무료로 먼저 켜 주세요.</p>' : '');
  return '<div class="tbn-in">' +
    '<button class="tbn-x" data-tbn="close" aria-label="닫기">' + icon('x') + '</button>' +
    '<header class="tbn-head"><div class="tbn-logo">🌱</div><h2 id="tbnTitle">텃밭투자집사 새 소식</h2><p>새로 열린 것들을 알려 드려요</p></header>' +
    h +
    '<p class="tbn-foot">이 안내는 앱을 켤 때마다 떠요. 그만 보려면 아래 <b>다시 보지 않기</b>를 체크하고 닫아 주세요.</p>' +
    '<div class="tbn-bar"><label class="tbn-off"><input type="checkbox" id="tbnOff"><span>다시 보지 않기</span></label>' +
      '<button class="btn btn-lg tbn-ok" data-tbn="close">닫기</button></div></div>';
}

function closeTbNotice(then) {
  const el = document.getElementById('tbNotice'); if (!el) return;
  const off = el.querySelector('#tbnOff');
  _tbnShown = true;                                         // 이번에 켠 동안은 다시 안 띄움
  if (off && off.checked) { UI.tbNoticeOff = TB_NOTICE_ID; saveUI(); }   // '다시 보지 않기' → 이 기기에서 영영 안 뜸
  el.remove();
  document.documentElement.classList.remove('tbn-open');
  document.removeEventListener('keydown', _tbnKey);
  if (typeof then === 'function') then();
}
function _tbnKey(e) { if (e.key === 'Escape') closeTbNotice(); }

function openTbNotice() {
  if (document.getElementById('tbNotice')) return;
  const el = document.createElement('div');
  el.id = 'tbNotice'; el.className = 'tbn';
  el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-labelledby', 'tbnTitle');
  el.innerHTML = tbNoticeHtml();
  hydrateIcons(el);
  document.body.appendChild(el);
  document.documentElement.classList.add('tbn-open');
  document.addEventListener('keydown', _tbnKey);
  el.addEventListener('click', e => {
    const b = e.target.closest('[data-tbn]'); if (!b) return;
    const a = b.dataset.tbn;
    if (a === 'board') closeTbNotice(() => go('board'));
    else if (a === 'quiz') closeTbNotice(() => go('game'));
    else if (a === 'dna') closeTbNotice(() => { if (typeof openDna === 'function') openDna(); });
    else closeTbNotice();
  });
  try { el.querySelector('.tbn-x').focus({ preventScroll: true }); } catch (e) {}
}

/* 켤 때: 화면이 비면(시작 애니메이션·약관 동의·이용권 잠금·업데이트 창이 끝나면) 한 번 띄움 */
function maybeTbNotice(tries) {
  tries = tries || 0;
  if (!tbNoticePending() || document.getElementById('tbNotice')) return;
  const lic = typeof LIC !== 'undefined' ? LIC : null;
  const ready = lic && (lic.active || !lic.required);                 // 이용권 확인이 끝났고 잠겨 있지 않음
  const busy = document.querySelector('.intro, #consentLock, #licLock, #appBlock, .ota-ov');
  if (!ready || busy) { if (tries < 400) setTimeout(() => maybeTbNotice(tries + 1), 1500); return; }   // 쿠폰을 넣는 동안도 기다림(10분)
  openTbNotice();
}
(function () {
  const start = () => setTimeout(() => maybeTbNotice(), 1500);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
  // 다른 앱에 3분 넘게 있다가 돌아오면(시작 애니메이션이 다시 나오는 때) 또 띄움 — 폰은 앱이 꺼지지 않고 남아 있는 경우가 많아서
  let hiddenAt = 0;
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { hiddenAt = Date.now(); return; }
    if (hiddenAt && Date.now() - hiddenAt > 3 * 60 * 1000 && !document.getElementById('tbNotice')) { _tbnShown = false; setTimeout(() => maybeTbNotice(), 1500); }
    hiddenAt = 0;
  });
})();
