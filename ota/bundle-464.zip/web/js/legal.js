/* ==========================================================================
   legal.js — ⚖️ 이용약관·투자 위험 고지·개인정보 동의 (v3.1)
   처음 켤 때(또는 약관 버전이 바뀌면) 세 가지 모두 동의해야 앱을 쓸 수 있음.
   동의 기록: UI.consent = { ver, at } (이 기기에만)
   ========================================================================== */
'use strict';

const LEGAL_VER = '2026-11-13';   // v4.26: 이용권 신청 정보(3-2) 추가 → 다시 동의 (v4.25: 사용 기기 확인·운영자 관계 고지)
const LEGAL_DOCS = [['terms', '이용약관', '정보 제공 서비스 · 투자자문·추천 아님 · 손실 책임은 본인'],
  ['risk', '투자 위험 고지', '원금 손실 가능 · 과거 성과·확률은 보장 아님'],
  ['privacy', '개인정보 처리방침', '기기 안 저장 · AI 회사로 보내는 계좌 요약']];
function consentNeeded() { return !(UI.consent && UI.consent.ver === LEGAL_VER); }
function openLegalDoc(k) {
  const d = LEGAL_DOCS.find(x => x[0] === k) || LEGAL_DOCS[0];
  openModal({ title: d[1], size: 'wide', top: !!document.getElementById('consentLock'), body: '<iframe class="legal-frame" src="/web/legal/' + d[0] + '.html" title="' + esc(d[1]) + '"></iframe>' });
}
function showConsent() {
  if (!consentNeeded() || document.getElementById('consentLock')) return;
  if (document.querySelector('.intro')) { setTimeout(showConsent, 500); return; }   // 시작 애니메이션이 끝난 뒤
  const el = document.createElement('div'); el.id = 'consentLock'; el.className = 'consent-lock';
  const again = !!UI.consent;
  el.innerHTML = '<div class="cl-box"><div class="cl-ico">⚖️</div><h2>' + (again ? '약관이 바뀌었어요' : '시작하기 전에 확인해 주세요') + '</h2>' +
    '<p class="cl-lead"><b>' + BRAND.name + '</b>는 투자 정보를 모아 정리하고 계산해 주는 <b>도구</b>예요. 종목을 추천하거나 사고팔 시점을 정해 주지 않아요. 결정과 책임은 언제나 본인에게 있어요.</p>' +
    '<label class="cl-all"><input type="checkbox" id="clAll"> <b>모두 동의</b></label>' +
    LEGAL_DOCS.map(([k, t, d]) => '<div class="cl-row"><label><input type="checkbox" data-k="' + k + '"> <span><b>[필수] ' + t + '</b><em>' + d + '</em></span></label><button class="cl-see" data-see="' + k + '">보기</button></div>').join('') +
    '<button class="btn btn-primary btn-lg btn-block" id="clGo" disabled>동의하고 시작하기</button>' +
    '<p class="cl-foot">동의 기록은 이 기기에만 저장돼요. 설정 → 약관·고지에서 언제든 다시 볼 수 있어요.</p></div>';
  document.body.appendChild(el);
  document.documentElement.style.overflow = 'hidden';
  const boxes = [...el.querySelectorAll('[data-k]')], go = el.querySelector('#clGo'), all = el.querySelector('#clAll');
  const sync = () => { const ok = boxes.every(b => b.checked); go.disabled = !ok; all.checked = ok; };
  boxes.forEach(b => b.onchange = sync);
  all.onchange = () => { boxes.forEach(b => { b.checked = all.checked; }); sync(); };
  el.addEventListener('click', e => { const s = e.target.closest('[data-see]'); if (s) { e.preventDefault(); openLegalDoc(s.dataset.see); } });
  go.onclick = () => {
    UI.consent = { ver: LEGAL_VER, at: Date.now() }; saveUI();
    el.remove(); document.documentElement.style.overflow = '';
    toast('고마워요! 이제 시작해요', 2000);
  };
}
// 설정 → 약관·고지
function legalSecHtml() {
  const notice = '<div class="callout gray" style="margin:0 0 10px">' + icon('info', 'ic-sm') + '<div>' + (ED === 'tb' ? '<b>배우는 사람 한 명이 혼자 만든 앱이에요.</b> 투자 교실이나 담쌤이 만들거나 확인·보증한 앱이 아니고, <b>공식 앱도 아니에요.</b> 부족한 점이나 틀린 곳은 모두 만든 사람의 탓이에요. 운영자는' : '<b>개인이 만든 앱이에요.</b> 증권사·금융회사·카페·유튜브와 관계없고, 운영자는') + ' <b>리딩·유료 상담·종목 추천을 하지 않아요.</b> 운영자를 사칭해 종목을 찍어 주거나 돈을 요구하면 사기예요. 앱은 운영자가 직접 준 주소에서만 받으세요.</div></div>';
  const c = UI.consent;
  return '<h2>약관·고지</h2>' + notice +
    '<div class="callout gray" style="margin-bottom:12px">' + icon('info', 'ic-sm') + '<div>이 앱은 <b>투자자문·투자일임·유사투자자문을 하지 않습니다.</b> 금융투자업 인가·등록을 받은 회사가 아니에요. 정보를 모아 정리·계산하는 도구이고, 투자 판단과 책임은 본인에게 있어요.</div></div>' +
    '<div class="legal-links">' + LEGAL_DOCS.map(([k, t, d]) => '<button class="set-row" data-see-legal="' + k + '"><div class="t"><b>' + t + '</b><span>' + d + '</span></div>' + icon('chevron-right', 'ic-sm') + '</button>').join('') + '</div>' +
    '<p class="note" style="margin:10px 2px 0">동의: ' + (c ? new Date(c.at).toLocaleString('ko-KR') + ' (약관 ' + esc(c.ver) + ')' : '아직 안 함') + '</p>' +
    '<div class="desc" style="margin-top:14px"><b>AI 추정 정확도 (이 기기 기록)</b> — ' + (function () { try { const v = aiTrackGrade(), g = v.map(r => trackRes(r, 'p7')).filter(x => x && x.hit != null); return g.length ? '1주 뒤 ' + g.filter(x => x.hit).length + '/' + g.length + '건 맞음 (' + Math.round(g.filter(x => x.hit).length / g.length * 100) + '%) · AI 추정은 자주 틀릴 수 있어요' : '아직 채점된 기록이 없어요'; } catch (e) { return '기록 없음'; } })() + '</div>' +
    '<div class="desc" style="margin-top:14px"><b>데이터 출처</b> — 시세: 네이버 증권·야후 파이낸스 (15~20분 늦을 수 있음) · 뉴스: 네이버 증권·연합뉴스·한국경제·매일경제·CNBC·MarketWatch·구글 뉴스·야후 · AI: 사용자가 연결한 AI 회사</div>';
}
document.addEventListener('click', e => { const b = e.target.closest('[data-see-legal]'); if (b) { e.preventDefault(); openLegalDoc(b.dataset.seeLegal); } });
